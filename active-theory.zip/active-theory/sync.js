/**
 * Active Theory Replica - Proactive Offline Asset Synchronizer
 * 
 * Crawls and downloads every asset (3D binary geometry, PBR textures,
 * shaders, audio, typography, UI data presets, and bundles)
 * directly into the local project folder.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const REMOTE_ORIGIN = 'https://activetheory.net';
const ROOT_DIR = __dirname;
const CONCURRENCY = 6;

function ensureDirSync(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

function downloadFile(fileUrl, destPath) {
    return new Promise((resolve) => {
        if (fs.existsSync(destPath) && fs.statSync(destPath).size > 0) {
            return resolve({ status: 'skipped', path: destPath });
        }

        ensureDirSync(destPath);
        const parsed = new URL(fileUrl);
        const client = parsed.protocol === 'https:' ? https : http;

        const req = client.get(fileUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': REMOTE_ORIGIN + '/'
            }
        }, (res) => {
            if (res.statusCode === 200) {
                const fileStream = fs.createWriteStream(destPath);
                res.pipe(fileStream);
                fileStream.on('finish', () => {
                    fileStream.close();
                    resolve({ status: 'downloaded', path: destPath, size: fs.statSync(destPath).size });
                });
                fileStream.on('error', (err) => {
                    fs.unlink(destPath, () => {});
                    resolve({ status: 'error', error: err.message, path: destPath });
                });
            } else if (res.statusCode === 301 || res.statusCode === 302) {
                const redirect = res.headers.location;
                const fullRedirect = redirect.startsWith('http') ? redirect : new URL(redirect, fileUrl).href;
                downloadFile(fullRedirect, destPath).then(resolve);
            } else {
                resolve({ status: 'failed', code: res.statusCode, path: destPath });
            }
        });

        req.on('error', (err) => {
            resolve({ status: 'error', error: err.message, path: destPath });
        });

        req.setTimeout(15000, () => {
            req.abort();
            resolve({ status: 'timeout', path: destPath });
        });
    });
}

async function runQueue(tasks, concurrency = CONCURRENCY) {
    let index = 0;
    let completed = 0;
    const total = tasks.length;

    async function worker() {
        while (index < tasks.length) {
            const current = tasks[index++];
            const result = await downloadFile(current.url, current.dest);
            completed++;
            const pct = ((completed / total) * 100).toFixed(1);
            if (result.status === 'downloaded') {
                console.log(`[${pct}%] [OK] ${path.relative(ROOT_DIR, current.dest)} (${(result.size / 1024).toFixed(1)} KB)`);
            } else if (result.status === 'skipped') {
                // already downloaded
            } else {
                console.warn(`[${pct}%] [${result.status.toUpperCase()} ${result.code || ''}] ${current.url}`);
            }
        }
    }

    const workers = [];
    for (let i = 0; i < concurrency; i++) {
        workers.push(worker());
    }
    await Promise.all(workers);
}

async function main() {
    console.log(`\n=============================================================`);
    console.log(`  ★ ACTIVE THEORY ASSET SYNC & CRAWLER ★`);
    console.log(`=============================================================\n`);
    console.log(`Target: ${REMOTE_ORIGIN}`);
    console.log(`Destination: ${ROOT_DIR}\n`);

    const knownAssets = new Set();

    // 1. Core Meta & Fonts
    const coreList = [
        'index.html',
        'unsupported.html',
        'assets/meta/apple-touch-icon.png',
        'assets/meta/favicon-32x32.png',
        'assets/meta/favicon-16x16.png',
        'assets/meta/manifest.json',
        'assets/meta/safari-pinned-tab.svg',
        'assets/fonts/NBArchitektStd-Regular-export/NBArchitektStd-Regular.woff2',
        'assets/fonts/NBArchitektStd-Regular-export/NBArchitektStd-Regular.woff',
        'assets/fonts/NBArchitektStd-Regular-export/NBArchitektStd-Regular.otf',
        'assets/fonts/NBArchitektStd-Light-export/NBArchitektStd-Light.woff2',
        'assets/fonts/NBArchitektStd-Light-export/NBArchitektStd-Light.woff',
        'assets/fonts/NBArchitektStd-Light-export/NBArchitektStd-Light.otf',
        'assets/fonts/NBArchitektStd-Bold-export/NBArchitektStd-Bold.woff2',
        'assets/fonts/NBArchitektStd-Bold-export/NBArchitektStd-Bold.woff',
        'assets/fonts/NBArchitektStd-Bold-export/NBArchitektStd-Bold.otf'
    ];
    coreList.forEach(a => knownAssets.add(a));

    // 2. Fetch cache version from index.html if possible
    let cacheVersion = '1780406240914';
    const indexPath = path.join(ROOT_DIR, 'index.html');
    if (fs.existsSync(indexPath)) {
        const indexHtml = fs.readFileSync(indexPath, 'utf8');
        const match = indexHtml.match(/_CACHE_\s*=\s*"([^"]+)"/);
        if (match) cacheVersion = match[1];
    }

    const uilPath = `assets/data/uil.${cacheVersion}.json`;
    const appJsPath = `assets/js/app.${cacheVersion}.js`;
    knownAssets.add(uilPath);
    knownAssets.add(appJsPath);

    console.log(`Step 1: Downloading core application bundles...`);
    await downloadFile(`${REMOTE_ORIGIN}/${uilPath}`, path.join(ROOT_DIR, uilPath));
    await downloadFile(`${REMOTE_ORIGIN}/${appJsPath}`, path.join(ROOT_DIR, appJsPath));

    // 3. Scan uil.json for 3D binary models, PBR textures, and environments
    const fullUilPath = path.join(ROOT_DIR, uilPath);
    if (fs.existsSync(fullUilPath)) {
        console.log(`Step 2: Parsing ${uilPath} for 3D assets and textures...`);
        try {
            const uilRaw = fs.readFileSync(fullUilPath, 'utf8');
            
            // Regex match all file references (.bin, .json, .png, .jpg, .jpeg, .ktx2, .mp4, .mp3, .ogg)
            const fileRegex = /"([^"]+\.(?:bin|json|png|jpg|jpeg|ktx2|mp4|webm|mp3|ogg|wav))(?:\?[^"]*)?"/gi;
            let m;
            while ((m = fileRegex.exec(uilRaw)) !== null) {
                const asset = m[1];
                if (!asset.startsWith('http://') && !asset.startsWith('https://')) {
                    knownAssets.add(asset.replace(/^\/+/, ''));
                }
            }

            // Also search for JSON structure values { src: "...", relative: "...", filename: "..." }
            const srcRegex = /"src"\s*:\s*"([^"]+)"/gi;
            while ((m = srcRegex.exec(uilRaw)) !== null) {
                let s = m[1].split('?')[0];
                if (s && !s.startsWith('http') && s.length > 2) {
                    knownAssets.add(s.replace(/^\/+/, ''));
                }
            }
        } catch (e) {
            console.error(`Error parsing ${uilPath}:`, e.message);
        }
    }

    // 4. Scan app.js for audio, 3D assets, video clips
    const fullAppJsPath = path.join(ROOT_DIR, appJsPath);
    if (fs.existsSync(fullAppJsPath)) {
        console.log(`Step 3: Deep scanning ${appJsPath}...`);
        try {
            const appRaw = fs.readFileSync(fullAppJsPath, 'utf8');
            const assetRegex = /assets\/[a-zA-Z0-9_\-\.\/]+\.(?:bin|json|png|jpg|jpeg|ktx2|mp4|webm|mp3|ogg|wav|woff2)/gi;
            let m;
            while ((m = assetRegex.exec(appRaw)) !== null) {
                knownAssets.add(m[0]);
            }
        } catch (e) {
            console.error(`Error reading ${appJsPath}:`, e.message);
        }
    }

    console.log(`Total discovered assets to sync: ${knownAssets.size}\n`);

    // Prepare download tasks
    const tasks = [];
    for (const relPath of knownAssets) {
        tasks.push({
            url: `${REMOTE_ORIGIN}/${relPath}`,
            dest: path.join(ROOT_DIR, relPath)
        });
    }

    console.log(`Step 4: Executing batch asset synchronization with ${CONCURRENCY} workers...\n`);
    await runQueue(tasks, CONCURRENCY);

    console.log(`\n=============================================================`);
    console.log(`  ★ ASSET SYNCHRONIZATION FINISHED ★`);
    console.log(`=============================================================`);
    console.log(`Run 'npm start' or 'node server.js' to launch your 100% replica.`);
    console.log(`Open http://localhost:3000 in your browser.\n`);
}

main().catch(console.error);
