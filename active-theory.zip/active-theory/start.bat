@echo off
title Active Theory Replica Server
echo =============================================================
echo   Starting Active Theory 100%% Replica Server...
echo =============================================================
echo.
echo Opening http://localhost:3000 in your browser...
start "" http://localhost:3000
echo Running server.js...
node server.js
pause
