/**
 * Active Theory Replica - Hybrid Local Server & On-Demand Mirroring Proxy
 * 
 * Features:
 * 1. Serves existing local assets with optimal caching, MIME types, and HTTP Range support (for videos/audio).
 * 2. On-demand Transparent Mirror: If an asset is requested that is not yet saved locally,
 *    it instantly fetches it from https://activetheory.net/, streams it directly to the browser,
 *    and simultaneously saves it to the local filesystem for 100% offline playback.
 * 3. Zero external dependencies (uses native Node.js http, https, fs, path, url, zlib).
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;
const REMOTE_ORIGIN = 'https://activetheory.net';
const GCS_ORIGIN = 'https://storage.googleapis.com/activetheory-v6.appspot.com';

const MIME_TYPES = {
    '.html': 'text/html; charset=UTF-8',
    '.htm': 'text/html; charset=UTF-8',
    '.js': 'application/javascript; charset=UTF-8',
    '.mjs': 'application/javascript; charset=UTF-8',
    '.json': 'application/json; charset=UTF-8',
    '.css': 'text/css; charset=UTF-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
    '.ktx2': 'image/ktx2',
    '.ico': 'image/x-icon',
    '.bin': 'application/octet-stream',
    '.glb': 'model/gltf-binary',
    '.gltf': 'model/gltf+json',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.otf': 'font/otf',
    '.ttf': 'font/ttf',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mp3': 'audio/mpeg',
    '.ogg': 'audio/ogg',
    '.wav': 'audio/wav',
    '.xml': 'application/xml',
    '.txt': 'text/plain; charset=UTF-8'
};

function ensureDirSync(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

function serveLocalFile(filePath, req, res) {
    const stat = fs.statSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    // Handle HTTP Range Requests (Critical for smooth video/audio streaming in WebGL scenes)
    const range = req.headers.range;
    if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;

        if (start >= stat.size) {
            res.writeHead(416, {
                'Content-Range': `bytes */${stat.size}`,
                'Access-Control-Allow-Origin': '*'
            });
            return res.end();
        }

        const chunksize = (end - start) + 1;
        const fileStream = fs.createReadStream(filePath, { start, end });
        res.writeHead(206, {
            'Content-Range': `bytes ${start}-${end}/${stat.size}`,
            'Accept-Ranges': 'bytes',
            'Content-Length': chunksize,
            'Content-Type': contentType,
            'Access-Control-Allow-Origin': '*'
        });
        fileStream.pipe(res);
    } else {
        res.writeHead(200, {
            'Content-Length': stat.size,
            'Content-Type': contentType,
            'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable',
            'Access-Control-Allow-Origin': '*'
        });
        fs.createReadStream(filePath).pipe(res);
    }
}

function fetchAndCache(targetUrl, localFilePath, req, res) {
    const parsedUrl = new URL(targetUrl);
    const client = parsedUrl.protocol === 'https:' ? https : http;

    const options = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: req.method,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': req.headers.accept || '*/*',
            'Accept-Encoding': 'identity', // avoid compressed streams on disk caching
            'Referer': REMOTE_ORIGIN + '/'
        }
    };

    if (req.headers.range) {
        options.headers['range'] = req.headers.range;
    }

    const proxyReq = client.request(options, (remoteRes) => {
        if (remoteRes.statusCode === 200) {
            ensureDirSync(localFilePath);
            const diskStream = fs.createWriteStream(localFilePath);
            
            // Set response headers
            const ext = path.extname(localFilePath).toLowerCase();
            const contentType = remoteRes.headers['content-type'] || MIME_TYPES[ext] || 'application/octet-stream';
            
            res.writeHead(200, {
                'Content-Type': contentType,
                'Content-Length': remoteRes.headers['content-length'],
                'Access-Control-Allow-Origin': '*',
                'Cache-Control': 'public, max-age=31536000'
            });

            remoteRes.pipe(diskStream);
            remoteRes.pipe(res);

            diskStream.on('finish', () => {
                console.log(`[CACHED TO DISK] ${path.relative(ROOT_DIR, localFilePath)}`);
            });

            diskStream.on('error', (err) => {
                console.error(`[DISK WRITE ERROR] ${localFilePath}:`, err.message);
            });
        } else if (remoteRes.statusCode === 206) {
            // Partial content range response
            res.writeHead(206, {
                'Content-Range': remoteRes.headers['content-range'],
                'Accept-Ranges': 'bytes',
                'Content-Length': remoteRes.headers['content-length'],
                'Content-Type': remoteRes.headers['content-type'],
                'Access-Control-Allow-Origin': '*'
            });
            remoteRes.pipe(res);
        } else if (remoteRes.statusCode === 301 || remoteRes.statusCode === 302) {
            const redirectUrl = remoteRes.headers.location;
            fetchAndCache(redirectUrl, localFilePath, req, res);
        } else {
            console.warn(`[REMOTE ${remoteRes.statusCode}] ${targetUrl}`);
            res.writeHead(remoteRes.statusCode, { 'Access-Control-Allow-Origin': '*' });
            remoteRes.pipe(res);
        }
    });

    proxyReq.on('error', (err) => {
        console.error(`[PROXY ERROR] Failed to fetch ${targetUrl}:`, err.message);
        res.writeHead(502, { 'Content-Type': 'text/plain' });
        res.end(`Proxy Error: Could not fetch resource from origin (${err.message})`);
    });

    proxyReq.end();
}

const server = http.createServer((req, res) => {
    const parsed = url.parse(req.url);
    let pathname = decodeURIComponent(parsed.pathname);

    // Default route
    if (pathname === '/' || pathname === '') {
        pathname = '/index.html';
    }

    // Direct clean URLs to index.html (SPA routing for Active Theory routes: /work, /about, /contact, etc.)
    const isStaticFile = path.extname(pathname) !== '';
    if (!isStaticFile) {
        pathname = '/index.html';
    }

    const safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
    const localFilePath = path.join(ROOT_DIR, safePath);

    // 1. If exists locally, serve immediately
    if (fs.existsSync(localFilePath) && fs.statSync(localFilePath).isFile()) {
        return serveLocalFile(localFilePath, req, res);
    }

    // 2. Otherwise mirror transparently from Active Theory production origin
    const remoteUrl = `${REMOTE_ORIGIN}${pathname}${parsed.search || ''}`;
    console.log(`[MIRRORING ON-DEMAND] Fetching ${pathname} from ${REMOTE_ORIGIN}...`);
    fetchAndCache(remoteUrl, localFilePath, req, res);
});

server.listen(PORT, () => {
    console.log(`\n=============================================================`);
    console.log(`  ★ ACTIVE THEORY 100% REPLICA SERVER RUNNING ★`);
    console.log(`=============================================================`);
    console.log(`  Local URL:        http://localhost:${PORT}`);
    console.log(`  Target Origin:    ${REMOTE_ORIGIN}`);
    console.log(`  Mirroring Mode:   Dynamic On-The-Fly Auto-Download & Disk Cache`);
    console.log(`  Workspace:        ${ROOT_DIR}`);
    console.log(`=============================================================\n`);
    console.log(`Open http://localhost:${PORT} in your web browser to view the replica.`);
    console.log(`All textures, shaders, 3D meshes, and code will be automatically saved locally.\n`);
});
