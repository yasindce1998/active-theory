# Active Theory 100% Replica

A complete, high-fidelity replica of **[Active Theory](https://activetheory.net/)** — world-renowned for its award-winning WebGL interactive experiences, fluid simulations, custom 3D shaders, dynamic camera choreography, and soundscapes.

---

## 🚀 Quick Start

### Method 1: Double-Click Launcher (Windows)
1. Double-click **`start.bat`**.
2. Your browser will automatically open [http://localhost:3000](http://localhost:3000).
3. The server serves the app and dynamically mirrors, streams, and saves all WebGL assets, shaders, 3D binary geometry, and audio directly to your disk!

### Method 2: Command Line (Node.js)
```bash
# Start the replica server
npm start
# or
node server.js
```
Open **[http://localhost:3000](http://localhost:3000)** in your browser.

---

## 📦 Offline Asset Synchronization (Optional)

If you wish to download all 3D geometries, PBR textures, environment maps, and audio assets ahead of time for 100% offline usage:

### Windows:
Double-click **`sync.bat`**.

### Terminal:
```bash
npm run sync
# or
node sync.js
```

---

## 🛠️ Architecture & Custom Software

| Component | File | Purpose |
| :--- | :--- | :--- |
| **Main Viewport & App Bootloader** | [`index.html`](file:///index.html) | Exact production HTML structure, viewport-fit, mobile/desktop CSS styling, NB Architekt font declarations, and SPA bootloader. |
| **Hybrid Server & On-Demand Mirror** | [`server.js`](file:///server.js) | Zero-dependency Node.js HTTP server. Serves local files with full HTTP Range support (for videos/audio). Transparently proxies and caches missing assets from `https://activetheory.net/` directly to disk in real-time. |
| **Batch Asset Crawler & Sync Engine** | [`sync.js`](file:///sync.js) | Custom crawler that parses `uil.json` and `app.js`, finds all 3D `.bin` geometries, KTX2/PNG/JPG PBR textures, and fonts, and downloads them using a multi-worker concurrency pool. |
| **Unsupported Browser Fallback** | [`unsupported.html`](file:///unsupported.html) | Fallback page for non-WebGL or older browser environments. |
| **One-Click Launchers** | [`start.bat`](file:///start.bat), [`start.sh`](file:///start.sh) | Launchers that start the server and open the replica in the default browser. |

---

## 🎨 Technical Highlights of Active Theory's Engine

1. **Hydra / Medusa Engine**: Custom WebGL 2.0 / WebGL 1.0 rendering framework designed by Active Theory.
2. **UIL Parameter Presets (`assets/data/uil.*.json`)**: Real-time camera curves, post-processing volumetric bloom, chromatic aberration, PBR materials, fog, and particle emitters.
3. **PBR & Custom Shader Pipelines**: Matcap reflections, normal mapping, dynamic refraction glass, and particle flow fields.
4. **Fluid Dynamics Simulation**: Mouse & pointer velocity-driven fluid simulation layers.
5. **Interactive Audio**: Real-time audio synthesis and sound FX tied to user interaction and scroll velocity.
