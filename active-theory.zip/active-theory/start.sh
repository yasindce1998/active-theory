#!/usr/bin/env bash
echo "============================================================="
echo "  Starting Active Theory 100% Replica Server..."
echo "============================================================="
echo ""

if which xdg-open > /dev/null; then
  xdg-open "http://localhost:3000" &
elif which open > /dev/null; then
  open "http://localhost:3000" &
fi

node server.js
