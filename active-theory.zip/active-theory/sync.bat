@echo off
title Active Theory Asset Sync
echo =============================================================
echo   Running Active Theory Offline Asset Synchronizer...
echo =============================================================
echo.
node sync.js
pause
